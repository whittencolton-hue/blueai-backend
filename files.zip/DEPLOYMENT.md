# BlueAI Backend - Deployment Guide

Your AI-powered backend for blue-collar trades. Includes pricing, scheduling, customer insights, safety monitoring, and chat.

---

## ⚡ Quick Start (10 minutes)

### Step 1: Get Your Claude API Key
1. Go to https://console.anthropic.com/account/keys
2. Sign in (create account if needed)
3. Click "Create Key"
4. **Copy the key** (you'll need it in Step 5)

### Step 2: Create a GitHub Account
1. Go to https://github.com
2. Sign up (it's free)
3. Create a new repository called `blueai-backend`

### Step 3: Upload These Files to GitHub
In your new repo, upload these 4 files:
- `server.js`
- `package.json`
- `.gitignore`
- `.env.example`

(You can drag and drop them into GitHub)

### Step 4: Create a Railway Account
1. Go to https://railway.app
2. Click "Start a New Project"
3. Sign in with your GitHub account
4. Click "Deploy from GitHub repo"
5. Select `blueai-backend`
6. Railway auto-detects it's Node.js and starts building

### Step 5: Add Your API Key to Railway
1. In the Railway dashboard, click your project
2. Go to the "Variables" tab
3. Click "Add Variable"
4. **Name:** `ANTHROPIC_API_KEY`
5. **Value:** (paste the key from Step 1)
6. Click "Save"

### Step 6: Deploy
Railway will auto-build and deploy. Watch for:
- ✅ "Deployment successful"
- Your live URL appears (like `https://blueai-backend-prod.up.railway.app`)

---

## 🧪 Test It Works

Once deployed, test each endpoint:

### 1. Health Check
```
https://YOUR-URL/health
```
Should return: `{"status":"alive","message":"BlueAI backend is running"}`

### 2. Pricing Recommendation
Open your browser or use curl:
```bash
curl -X POST https://YOUR-URL/api/pricing \
  -H "Content-Type: application/json" \
  -d '{"jobType":"HVAC","parts":3200,"estimate":4800}'
```

### 3. Schedule Optimization
```bash
curl -X POST https://YOUR-URL/api/schedule/optimize \
  -H "Content-Type: application/json" \
  -d '{"jobs":[{"id":1,"title":"Job A","duration":"4h"},{"id":2,"title":"Job B","duration":"3h"}]}'
```

### 4. Customer Churn Insights
```bash
curl https://YOUR-URL/api/insights/churn
```

### 5. AI Chat Assistant
```bash
curl -X POST https://YOUR-URL/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message":"Which customer should I follow up with?"}'
```

### 6. Safety Checklist
```bash
curl -X POST https://YOUR-URL/api/safety/checklist \
  -H "Content-Type: application/json" \
  -d '{"jobType":"electrical","jobDetails":{"location":"residential","crew_size":2}}'
```

---

## 📍 What Each Endpoint Does

| Endpoint | What it does |
|----------|-------------|
| `POST /api/pricing` | AI suggests what price to quote for a job |
| `POST /api/schedule/optimize` | AI finds ways to save time & money in your schedule |
| `GET /api/insights/churn` | AI identifies which customers might leave |
| `POST /api/chat` | AI assistant answers worker/owner questions |
| `POST /api/safety/checklist` | AI generates job-specific safety requirements |
| `GET /health` | Check if server is running |

---

## 🚀 Connect to Your Frontend

In your dashboard (from earlier), update API calls to point to your live URL:

```javascript
// Before
const res = await fetch("http://localhost:3000/api/pricing", ...)

// After
const res = await fetch("https://your-railway-url/api/pricing", ...)
```

---

## 🔧 Local Testing (Optional)

Want to test on your computer first?

1. Install Node.js from nodejs.org
2. In terminal:
```bash
npm install
npm start
```
3. Visit `http://localhost:3000/health`

---

## 💡 Next Steps

1. **Test all 6 endpoints** (use the curl commands above)
2. **Connect the dashboard UI** to your live URLs
3. **Add real data** instead of sample jobs/customers
4. **Invite 5 beta users** from your target trade
5. **Iterate based on feedback**

---

## ❓ Troubleshooting

**"Deployment failed"**
- Check that `.gitignore` includes `node_modules/`
- Make sure `package.json` is in the root folder

**"API key not found"**
- Verify you added the `ANTHROPIC_API_KEY` variable in Railway
- Make sure it's the full key, not partial

**"Cannot POST /api/pricing"**
- Check your URL matches Railway's URL exactly
- Make sure you're including `/api/pricing` at the end

---

**Questions? The code is yours to modify. Good luck! 🎉**
