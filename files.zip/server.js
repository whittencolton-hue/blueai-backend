const express = require("express");
const cors = require("cors");
const Anthropic = require("@anthropic-ai/sdk");

const app = express();
app.use(cors());
app.use(express.json());

const client = new Anthropic();

// Sample data (in real app, this would be a database)
const jobs = [
  { id: 2847, title: "Bathroom Remodel", crew: "Jake + David", hours: 8, estimate: 2100 },
  { id: 2851, title: "Electrical Work", crew: "Emma (licensed)", hours: 6, estimate: 3500 },
  { id: 2853, title: "HVAC Service", crew: "Miguel", hours: 4, estimate: 1800 },
];

const customers = [
  { id: 1, name: "Riverside Properties Inc.", lastJob: 8, revenue: 3200 },
  { id: 2, name: "Downtown Shopping Center", lastJob: 2, revenue: 12400 },
  { id: 3, name: "Metro Residential Group", lastJob: 1, revenue: 8900 },
];

// ============================================
// PRICING RECOMMENDATION ENDPOINT
// ============================================
app.post("/api/pricing", async (req, res) => {
  const { jobType, parts, estimate } = req.body;

  try {
    const message = await client.messages.create({
      model: "claude-sonnet-4-6",
      max_tokens: 300,
      messages: [
        {
          role: "user",
          content: `You are a pricing expert for blue-collar trades. 
        
Job Type: ${jobType}
Part Costs: $${parts}
Current Estimate: $${estimate}

Based on market rates, complexity, and typical margins, suggest a final price.
Return ONLY a JSON object with:
{
  "suggested_price": NUMBER,
  "reasoning": "2-3 sentence explanation",
  "confidence": "high/medium/low"
}`,
        },
      ],
    });

    const responseText = message.content[0].text;
    const pricing = JSON.parse(responseText);

    res.json({
      currentEstimate: estimate,
      suggestedPrice: pricing.suggested_price,
      potentialIncrease: pricing.suggested_price - estimate,
      reasoning: pricing.reasoning,
      confidence: pricing.confidence,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ============================================
// SCHEDULE OPTIMIZATION ENDPOINT
// ============================================
app.post("/api/schedule/optimize", async (req, res) => {
  const { jobs: inputJobs } = req.body;

  try {
    const message = await client.messages.create({
      model: "claude-sonnet-4-6",
      max_tokens: 500,
      messages: [
        {
          role: "user",
          content: `You are a scheduling expert for blue-collar trades.

Current jobs scheduled:
${JSON.stringify(inputJobs, null, 2)}

Analyze this schedule and suggest optimizations. Return ONLY a JSON object with:
{
  "optimizations": [
    {
      "action": "description of change",
      "savings": "time or money saved",
      "priority": "high/medium/low"
    }
  ],
  "total_time_saved": "hours",
  "total_cost_saved": "dollars",
  "crew_utilization": "percentage"
}`,
        },
      ],
    });

    const responseText = message.content[0].text;
    const optimization = JSON.parse(responseText);

    res.json(optimization);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ============================================
// CUSTOMER INSIGHTS ENDPOINT
// ============================================
app.get("/api/insights/churn", async (req, res) => {
  try {
    const message = await client.messages.create({
      model: "claude-sonnet-4-6",
      max_tokens: 400,
      messages: [
        {
          role: "user",
          content: `Analyze these customers for churn risk:
        
${JSON.stringify(customers, null, 2)}

Return ONLY a JSON object with:
{
  "at_risk": [
    {
      "customer_name": "name",
      "risk_level": "high/medium/low",
      "reason": "why they might churn",
      "recommended_action": "what to do"
    }
  ],
  "upsell_opportunities": [
    {
      "customer_name": "name",
      "opportunity": "service they haven't used",
      "estimated_value": "dollars"
    }
  ]
}`,
        },
      ],
    });

    const responseText = message.content[0].text;
    const insights = JSON.parse(responseText);

    res.json(insights);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ============================================
// AI CHAT ASSISTANT ENDPOINT
// ============================================
app.post("/api/chat", async (req, res) => {
  const { message, context } = req.body;

  try {
    const message_response = await client.messages.create({
      model: "claude-sonnet-4-6",
      max_tokens: 500,
      messages: [
        {
          role: "user",
          content: `You are BlueAI, an AI assistant for blue-collar trade businesses. 
        
Context - Current Jobs:
${JSON.stringify(jobs, null, 2)}

Context - Current Customers:
${JSON.stringify(customers, null, 2)}

User question: "${message}"

Be concise, helpful, and actionable. Give specific numbers/recommendations when possible.`,
        },
      ],
    });

    res.json({
      response: message_response.content[0].text,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ============================================
// SAFETY MONITORING ENDPOINT
// ============================================
app.post("/api/safety/checklist", async (req, res) => {
  const { jobType, jobDetails } = req.body;

  try {
    const message = await client.messages.create({
      model: "claude-sonnet-4-6",
      max_tokens: 400,
      messages: [
        {
          role: "user",
          content: `Generate a safety checklist for a ${jobType} job.

Job details: ${JSON.stringify(jobDetails)}

Return ONLY a JSON object with:
{
  "checklist": [
    {
      "item": "safety requirement",
      "priority": "critical/high/medium",
      "reason": "why this matters"
    }
  ],
  "compliance_level": "percentage",
  "common_hazards": ["hazard 1", "hazard 2"]
}`,
        },
      ],
    });

    const responseText = message.content[0].text;
    const safetyCheck = JSON.parse(responseText);

    res.json(safetyCheck);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ============================================
// HEALTH CHECK ENDPOINT
// ============================================
app.get("/health", (req, res) => {
  res.json({ status: "alive", message: "BlueAI backend is running" });
});

// ============================================
// START SERVER
// ============================================
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 BlueAI backend running on port ${PORT}`);
  console.log(`📝 Health check: http://localhost:${PORT}/health`);
});
